The Release file , relative Data Template and Configuration Setting file be got from attachments please.
In addition, there are some folders before running process as below:
1.           C:\Download
2.           C:\RPA Demo\Result
3.           C:\RPA Demo\SourceData
4.           C:\RPA Demo\Template   --> here includes Data Template and Configuration Setting files.
